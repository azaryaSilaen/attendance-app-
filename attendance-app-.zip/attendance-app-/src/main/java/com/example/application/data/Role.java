package com.example.application.data;

public enum Role {
    ADMIN, SUPERVISOR, OFFICER;
}
