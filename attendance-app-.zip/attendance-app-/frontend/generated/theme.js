import {applyTheme as _applyTheme} from './theme-attendanceapp.generated.js';
export const applyTheme = _applyTheme;
