


if (!document['_vaadintheme_attendanceapp_componentCss']) {
  
  document['_vaadintheme_attendanceapp_componentCss'] = true;
}

if (import.meta.hot) {
  import.meta.hot.accept((module) => {
    window.location.reload();
  });
}

